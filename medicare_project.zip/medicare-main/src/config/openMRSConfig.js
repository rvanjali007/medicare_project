const options = {
  method: "GET",
  url: "https://beta.myupchar.com/api/medicine/search?api_key=9034ee789fdd6d2ffc9f586eee877ec7",
};

module.exports = { options };

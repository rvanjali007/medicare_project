import React from "react";
// import './Home.css'

const ClickMe1 = () => {
  return <div>
    Click ME
  </div>;
};

export default ClickMe1;
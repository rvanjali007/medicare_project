import React from "react";
import "./OrderMedicine.css";
import Card from "../Card/Card";

const OrderMedicine = () => {
  return (
    <>
      <div className="grid-container">
        <div className="grid-item">
          <Card />
        </div>
        <div className="grid-item">
          {/* <Card /> */}
        </div>
        <div className="grid-item">
          {/* <Card /> */}
        </div>
        <div className="grid-item">
          {/* <Card /> */}
        </div>
        <div className="grid-item">
          {/* <Card /> */}
        </div>
        <div className="grid-item">
          {/* <Card /> */}
        </div>
        
      </div>
    </>
  );
};

export default OrderMedicine;

import React from "react";

const Testimonials = ()=>{
    return(
        <>
        testimonials
        
        </>
    )
}

export default Testimonials;
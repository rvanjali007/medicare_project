import React from "react";

const Service = ()=>{
    return(
        <>
        sevice
         </>
    )
}

export default Service;

import React from "react";

const Appointment = ()=>{
    return(
        <>
        Appointment
        
        </>
    )
}

export default Appointment;